This directory is for bugs in RML that shouldn't hold up a distribution but that should be fixed.

Each RML file when placed here should be one that currently breaks in rml2pdf that illustrates the bug. 
When the bug is fixed, the file should still stay here.

It should NOT ship with a distribution.

If a customer send us a buggy file, it can be place here.



Naming conventions:
------------------
bugNNN_somethingMeaningful.rml
(Where NNN is the next available bug number